export interface Autor {
    primeiro_nome: string,
    ultimo_nome: string
}