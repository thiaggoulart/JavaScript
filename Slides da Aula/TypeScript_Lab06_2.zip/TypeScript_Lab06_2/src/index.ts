import app from './app';

//Conectar ao MongoDB

app.listen(app.get('port'), () => {
    console.log(`Express executando em http://localhost:${app.get('port')} no modo ${app.get('env')}`);
});
