import {Autor} from './autor';

export interface Livro {
    titulo: string,
    autores: Autor[]
}