import express from 'express';
import bodyParser from 'body-parser';
import errorhandler from 'errorhandler';

const PORT = 3000;
const app = express();
app.set('port', process.env.PORT || PORT);
app.use(bodyParser.json());
if (process.env.NODE_ENV !== "production") {
    app.use(errorhandler());
}
export default app;